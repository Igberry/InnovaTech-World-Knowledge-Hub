# Opening hours (fictional)

| Day | Hours |
|---|---|
| Monday | 9:00 – 21:00 |
| Tuesday | 9:00 – 21:00 |
| Wednesday | 9:00 – 21:00 |
| Thursday | 9:00 – 21:00 |
| Friday | 9:00 – 22:00 |
| Saturday | 10:00 – 22:00 |
| Sunday | 12:00 – 20:00 |

Last orders 30 minutes before closing. Public holidays may differ.
