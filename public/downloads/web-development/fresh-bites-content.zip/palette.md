# Brand palette & fonts — Yenagoa Fresh Bites

Use these for the **restaurant** project (warm food colours — deliberately different from
InnovaTech's blue, so you practise applying any brand).

## Colours

| Token | Hex | Use |
|---|---|---|
| Tomato (primary) | `#C8372D` | Buttons, headings accent, highlights |
| Deep tomato | `#9E2A22` | Hover/pressed states |
| Warm cream | `#FFF7ED` | Page background |
| Charcoal | `#2B2320` | Main text |
| Leaf green | `#2E7D4F` | "Veg" tags, success |
| Golden | `#E8A33D` | Secondary accent (use sparingly) |
| Soft border | `#EADFD3` | Card borders, dividers |

## Fonts (free, from Google Fonts)

- **Headings:** Poppins or Fraunces (pick one; Fraunces gives a tastier, editorial feel).
- **Body:** Inter or system UI stack.

## Tone of voice

Warm, friendly, appetising. Short sentences. "Made fresh to order." Avoid hype.
