# Yenagoa Fresh Bites — Content Kit

> **Everything here is FICTIONAL.** "Yenagoa Fresh Bites" is a made-up business created only for
> practice in the InnovaTech World Web Development course. The address, phone, prices and story are
> invented. Do not present this as a real business.

You will build every project in this course for this one fictional restaurant, so your skills stack
up into a real portfolio. Use this kit as your source of truth for content.

## The brief

- **Name:** Yenagoa Fresh Bites
- **What it is:** A small restaurant and takeaway in Yenagoa serving fresh Nigerian home-style food.
- **Tagline:** *Fresh, local, made to order.*
- **Who it serves:** Busy workers, students and families in Yenagoa who want tasty, affordable meals
  and easy takeaway or reservations.
- **Personality:** Warm, friendly, clean, proudly local. Not fancy — honest and welcoming.
- **What the website must do:** Show the menu and prices, opening hours and location, and let people
  send a reservation or takeaway request through a form.

## Fictional details (use these exactly)

- **Address (fictional):** 12 Mbiama Road, Yenagoa, Bayelsa State
- **Phone (fictional, do not call):** +234 800 000 0000
- **Email (fictional):** hello@freshbites.example
- **Area served:** Yenagoa and nearby

## Files in this kit

| File | What it is |
|---|---|
| `menu.json` | The full menu as data (use this in your JavaScript/React projects) |
| `menu.csv` | The same menu as a spreadsheet (open in Excel) |
| `opening-hours.md` | Opening hours |
| `palette.md` | The brand colours and fonts to use for the *restaurant* site |
| `images/` | Simple SVG placeholders (logo, hero, a dish). Replace or restyle freely. |

## Rules for your project

- Use the **warm food palette** in `palette.md` for the restaurant — **not** InnovaTech's blue. Part
  of the skill is applying a brand that is not your own.
- Prices are in **Naira (₦)**. Format them in code with `Intl.NumberFormat("en-NG", { style: "currency", currency: "NGN" })`.
- Do not use copyrighted photos. The SVG placeholders here are yours to use and change. If you want
  real photos later, use only free-licence images (e.g. Unsplash) and credit them.
